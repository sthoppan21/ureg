## Angular 4 Template Driven Forms : Building and Validating Forms  

This exmaple show you have to build a form and integrate validation using Template-driven forms in Angualr 4.

### Template-driven Forms

Template-driven forms it most similar to the AngularJS forms in Angular 1. It using the models for driven approach. So, Template Drive Forms are uses the Angular directives in the the template to handling the forms. 

### Validation

Validation is used to ensure the user entering the valid data. Validation is most important for every form in web application to ensure user to enter valid data to work with and we must provide meaningful and understandable message to help user to enter valid data. 

Angular 4 is providing some common validation like : required, email, maxLength, minLength, etc …
